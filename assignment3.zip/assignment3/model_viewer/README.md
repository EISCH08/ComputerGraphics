# Computer Graphics, Assignment 3, Part 1 and 2

Follow the build instructions from Assignment 2, but replace
ASSIGNMENT2_ROOT with ASSIGNMENT3_ROOT.
